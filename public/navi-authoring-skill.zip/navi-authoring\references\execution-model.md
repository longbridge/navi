# Navi Execution Model

How Navi scripts *run*. This is where most subtle bugs live — get the mental
model right before writing calculations. For pure surface syntax, see
[syntax.md](syntax.md).

## Table of Contents

- [Bar-by-bar execution](#bar-by-bar-execution)
- [Type qualifiers: const / input / simple / series](#type-qualifiers-const--input--simple--series)
- [Declaration modes: var / varip / none](#declaration-modes-var--varip--none)
- [Rollback and real-time bars](#rollback-and-real-time-bars)
- [na — missing values](#na--missing-values)
- [History references `[]`](#history-references-)
- [Non-repainting and look-ahead](#non-repainting-and-look-ahead)

## Bar-by-bar execution

A Navi script does not run once — the engine executes the **whole script once
per candlestick (bar)**, walking chronologically from the first bar to the last.
Every `let`, every expression, every `plot` runs again on each bar. A "series"
is therefore the sequence of values a variable takes as the script re-runs bar
after bar.

Two consequences shape everything else:

- A plain `let x = …;` is **re-initialized on every bar** — it does not remember
  the previous bar. To carry state forward you need `var`/`varip`.
- The value "at bar N" of any expression is fixed once that bar closes. To look
  back you use history references (`x[1]`), never a stored copy.

The engine also re-runs the current (rightmost) bar on each incoming real-time
tick — see [Rollback](#rollback-and-real-time-bars).

## Type qualifiers: const / input / simple / series

Every Navi type carries a **qualifier** describing *when* the value is known.
From most to least restrictive:

| Qualifier | Known… | Changes? |
|-----------|--------|----------|
| `const` | at compile time | never |
| `input` | at script startup | never during the run |
| `simple` | on bar 0 | same on every bar |
| `series` | any bar | can differ each bar |

```navi
let a: const int = 2;
let b: input int = input.int(10);
let c: simple int = a + b;   // combines const + input → simple
let d: series float = close; // price data is series
```

The hierarchy flows **one way**: `const → input → simple → series`. A value can
be auto-**promoted** up this chain but never demoted. So:

- A `series` value **cannot** be used where `simple`/`input`/`const` is required.
  Many `ta.*` functions require a `simple int` length — you can pass a `const`
  literal or an `input.int`, but **not** a `series int` that changes per bar.

```navi
let len = input.int(14, "Length"); // input int — OK as a length
plot(ta.sma(close, len));

let bad = int(close);              // series int — NOT accepted as a length
// plot(ta.sma(close, bad));       // error: expected simple int
```

Most price-based values (`close`, `high`, …) and most `ta.*` outputs are
`series`. Numeric literals and `true`/`false` are `const`. `input.*` results are
`input`.

## Declaration modes: var / varip / none

The declaration keyword controls **initialization timing and persistence**:

| Behavior | No keyword (`let`) | `var` | `varip` |
|----------|--------------------|-------|---------|
| Initialization | every execution | once (first bar) | once (first bar) |
| Historical bars | re-init each bar | persists | persists |
| Real-time ticks | re-init each tick | persists (with rollback) | persists (no rollback) |

```navi
indicator("Green Bars Count");
var count = 0;               // initialized once, then kept across bars
if close >= open {
    count = count + 1;       // reassignment persists because of `var`
}
plot(count);
```

Without `var`, `count` would reset to `0` every bar and the plot could only ever
show `0` or `1`.

`var` can also be declared **inside an `if` block** — it is initialized on the
first execution that enters that branch — and works with any type, including
arrays that grow across bars:

```navi
var a = Array.new<float>(0);
a.push(close);               // grows by one element each bar
```

`varip` (var-intrabar-persist) is like `var` but **not subject to rollback**
(next section). Use it only when you deliberately want tick-level state on the
forming bar. It can also be applied to **individual struct fields**:

```navi
struct Counter {
    int bars = 0,
    varip int ticks = 0,
}
var counter: Counter = Counter.new();
counter.bars += 1;  // rolls back on unconfirmed bars
counter.ticks += 1; // NOT subject to rollback
```

## Rollback and real-time bars

On **historical** bars `var` and `varip` behave identically, because the script
runs exactly once per bar.

The difference shows on the **real-time** (rightmost, unconfirmed) bar, which the
engine re-executes on every incoming tick:

- `var` is subject to **rollback**: at the start of each new tick the value
  reverts to what it was at the last confirmed bar, then the script re-runs. So
  `var` stays consistent per *confirmed* bar.
- `varip` is **not** rolled back: it keeps accumulating across every tick within
  the forming bar.

```navi
varip updateCount: int = na;
if barstate.is_new {
    updateCount = 1;          // reset when a fresh bar opens
} else {
    updateCount = updateCount + 1; // count ticks within the bar
}
plot(updateCount, style: PlotStyle.Circles);
```

Prefer `var` for state that should be consistent per confirmed bar. Reach for
`varip` only for genuine intra-bar tick tracking — and be aware it can repaint.

## na — missing values

`na` represents a missing/undefined value and propagates through most
calculations. A rolling function returns `na` until it has enough data (e.g.
`ta.sma(close, 5)` is `na` for the first 4 bars). **Never assume `na` behaves
like 0** — test for it explicitly.

```navi
let sma5 = ta.sma(close, 5);
if not na(sma5) {
    label.new(bar_index, sma5, str.tostring(sma5));
}
```

Three prelude helpers:

- `na(x)` → `true` if `x` is missing.
- `nz(x, replacement)` → `x`, or `replacement` when `x` is `na` (default `0`).
- `fixnan(x)` → `x`, or the **last non-na value** when `x` is `na`.

`fixnan` is a clean illustration of `var`-based state — it remembers the last
good value across bars:

```navi
export fn fixnan<T>(value: series T): series T {
    var last: T = na;
    if na(value) {
        last          // reuse the remembered value
    } else {
        last = value  // update and return it
    }
}
```

## History references `[]`

`x[N]` retrieves the value `x` **had N bars ago**. It reads the
already-computed historical result — it does **not** re-evaluate the expression
with old inputs.

```navi
let previousClose = close[1];
let prevSma = ta.sma(close, 14)[1]; // the SMA computed on the previous bar
```

Rules:

- The offset is a non-negative integer and **may itself be `series`**
  (`close[i]` inside a loop is fine).
- On early bars where history is insufficient, the result is `na`.
- A history reference **promotes the qualifier to `series`**.
- Chaining is additive: `close[1][1]` equals `close[2]`.
- To look back further than the default buffer, extend it with
  `max_bars_back(series, n)`.

This is the correct way to compare against the past — e.g. an explicit cross:

```navi
let crossedUp = fast > slow and fast[1] <= slow[1];
```

## Non-repainting and look-ahead

A script **repaints** when the value it shows for a historical bar differs from
what it showed live — usually because the logic depended on data that wasn't
available yet when that bar was forming.

Guidelines for non-repainting output:

- Don't make committed output depend on the unconfirmed state of the current
  bar. If you need real-time behavior, isolate it and document it. Remember
  `varip` and intra-bar `if barstate.is_realtime` logic can repaint by design.
- Never reach forward in time — there are no forward references, and
  `request.security(...)` must avoid look-ahead (use confirmed values, not the
  in-progress higher-timeframe bar).
- `barstate.is_confirmed` is true only once the bar has closed; gate
  side-effects (alerts, orders you want final) on confirmation when appropriate.

When correctness matters, prefer values that are stable once a bar closes, and
verify a historical replay produces the same plots as the live run.
